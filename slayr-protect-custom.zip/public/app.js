const $ = s => document.querySelector(s);
let authMode = "login", inputMode = "paste", latestOutput = "";
async function api(url, options = {}) {
  const isForm = options.body instanceof FormData;
  const response = await fetch(url, { credentials: "same-origin", ...options,
    headers: { ...(isForm ? {} : { "Content-Type": "application/json" }), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function setMessage(el, text, success=false) { el.textContent=text; el.classList.toggle("success",success); }
function notify(text) { const el=$("#toast"); el.textContent=text; el.classList.remove("hidden"); clearTimeout(notify.timer); notify.timer=setTimeout(()=>el.classList.add("hidden"),2600); }
function showAuth(){ $("#authScreen").classList.remove("hidden"); $("#appScreen").classList.add("hidden"); }
function showApp(){ $("#authScreen").classList.add("hidden"); $("#appScreen").classList.remove("hidden"); }
function fmtBytes(n){ if(!n)return "0 B"; const units=["B","KB","MB"]; let i=0,v=n; while(v>=1024&&i<units.length-1){v/=1024;i++;}return `${v.toFixed(i?1:0)} ${units[i]}`; }
function prettyDate(s){ const d=new Date(s+"Z"); return isNaN(d)?"—":d.toLocaleString(undefined,{month:"short",day:"numeric",year:"numeric",hour:"numeric",minute:"2-digit"}); }
function renderDashboard(data){
  $("#sideUsername").textContent=data.user.username; $("#sideAvatar").textContent=data.user.username.charAt(0).toUpperCase();
  $("#welcomeUsername").textContent=data.user.username; $("#settingsUsername").value=data.user.username;
  $("#statJobs").textContent=data.stats.total; $("#statBytes").textContent=fmtBytes(data.stats.sourceBytes);
  const list=$("#recentJobs"); list.replaceChildren();
  if(!data.recent.length){
    const empty=document.createElement("div"); empty.className="empty-state";
    const symbol=document.createElement("div");symbol.textContent="⌘";
    const title=document.createElement("b");title.textContent="No scripts processed yet";
    const p=document.createElement("p");p.textContent="Your completed jobs will show up here.";
    empty.append(symbol,title,p);list.append(empty);return;
  }
  data.recent.forEach(job=>{
    const row=document.createElement("div");row.className="job-row";
    const ico=document.createElement("div");ico.className="job-icon";ico.textContent="⌘";
    const meta=document.createElement("div");meta.className="job-meta";
    const title=document.createElement("b");title.textContent=job.name;
    const sub=document.createElement("small");sub.textContent=(job.description||"Luau script")+" · "+prettyDate(job.created_at);
    const size=document.createElement("div");size.className="job-size";size.textContent=fmtBytes(job.source_bytes);
    const small=document.createElement("small");small.textContent="Source size";size.append(small);
    meta.append(title,sub);row.append(ico,meta,size);list.append(row);
  });
}
async function refreshDashboard(){
  try{const data=await api("/api/me");renderDashboard(data);showApp();}
  catch{showAuth();}
}
document.querySelectorAll("[data-auth]").forEach(button=>button.addEventListener("click",()=>{
  authMode=button.dataset.auth;
  document.querySelectorAll("[data-auth]").forEach(b=>b.classList.toggle("selected",b===button));
  $("#authSubmit").innerHTML=authMode==="login"?'Sign in <span>→</span>':'Create account <span>→</span>';
  $("#authPassword").autocomplete=authMode==="login"?"current-password":"new-password";
  setMessage($("#authMessage"),"");
}));
$("#authForm").addEventListener("submit",async e=>{
  e.preventDefault();const button=$("#authSubmit");button.disabled=true;setMessage($("#authMessage"),"");
  try{const data=await api(`/api/auth/${authMode}`,{method:"POST",body:JSON.stringify({username:$("#authUsername").value,password:$("#authPassword").value})});$("#authPassword").value="";renderDashboard(data.dashboard);showApp();}
  catch(err){setMessage($("#authMessage"),err.message);}
  finally{button.disabled=false;}
});
function navigate(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
  $(`#page-${page}`).classList.remove("hidden");
  document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  const label=page.toUpperCase();$("#crumbPage").textContent=label;$("#topTitle").textContent=page==="obfuscation"?"Obfuscation":page[0].toUpperCase()+page.slice(1);
}
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.goto)));
async function logout(){try{await api("/api/auth/logout",{method:"POST",body:"{}"});}catch{}showAuth();navigate("dashboard");}
$("#logoutSmall").addEventListener("click",logout);$("#logoutButton").addEventListener("click",logout);
document.querySelectorAll("[data-mode]").forEach(b=>b.addEventListener("click",()=>{
  inputMode=b.dataset.mode;
  document.querySelectorAll("[data-mode]").forEach(x=>x.classList.toggle("selected",x===b));
  $("#pastePanel").classList.toggle("hidden",inputMode!=="paste");
  $("#uploadPanel").classList.toggle("hidden",inputMode!=="upload");
}));
$("#sourceCode").addEventListener("input",()=>$("#charCount").textContent=$("#sourceCode").value.length.toLocaleString()+" characters");
$("#sourceFile").addEventListener("change",()=>{$("#fileName").textContent=$("#sourceFile").files[0]?$("#sourceFile").files[0].name:"";});
$("#transformForm").addEventListener("submit",async e=>{
  e.preventDefault();const button=$("#transformButton");button.disabled=true;$("#resultPanel").classList.add("hidden");setMessage($("#transformMessage"),"Processing script…");
  try{
    let data;
    if(inputMode==="upload"){
      const file=$("#sourceFile").files[0];if(!file)throw new Error("Choose a .lua or .luau file first.");
      const form=new FormData();form.append("name",$("#scriptName").value);form.append("description",$("#scriptDescription").value);form.append("file",file);
      data=await api("/api/obfuscate-file",{method:"POST",body:form});
    }else{
      data=await api("/api/obfuscate",{method:"POST",body:JSON.stringify({name:$("#scriptName").value,description:$("#scriptDescription").value,code:$("#sourceCode").value})});
    }
    latestOutput=data.output;$("#outputCode").value=latestOutput;$("#outputSummary").textContent=`${latestOutput.length.toLocaleString()} output characters · ${fmtBytes(new Blob([latestOutput]).size)}`;
    $("#resultPanel").classList.remove("hidden");setMessage($("#transformMessage"),data.notice,true);await refreshDashboard();
  }catch(err){setMessage($("#transformMessage"),err.message);}
  finally{button.disabled=false;}
});
$("#copyResult").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(latestOutput);notify("Output copied to clipboard.");}catch{notify("Clipboard access was blocked by your browser.");}});
$("#downloadResult").addEventListener("click",()=>{const blob=new Blob([latestOutput],{type:"text/plain;charset=utf-8"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=(($("#scriptName").value||"slayr-output").replace(/[^a-z0-9_-]/gi,"_"))+".luau";document.body.append(a);a.click();a.remove();URL.revokeObjectURL(url);});
$("#passwordForm").addEventListener("submit",async e=>{
  e.preventDefault();const el=$("#passwordMessage");
  try{await api("/api/change-password",{method:"POST",body:JSON.stringify({currentPassword:$("#currentPassword").value,newPassword:$("#newPassword").value})});setMessage(el,"Password updated.",true);$("#passwordForm").reset();}
  catch(err){setMessage(el,err.message);}
});
refreshDashboard();
