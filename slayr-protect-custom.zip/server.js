require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

if (process.env.NODE_ENV === "production" && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  console.warn("WARNING: Set SESSION_SECRET to a random value at least 32 characters long.");
}
const app = express();
app.set("trust proxy", 1);
const port = process.env.PORT || 3000;
const dataDir = process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "slayr.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS jobs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 source_bytes INTEGER NOT NULL DEFAULT 0,
 output_bytes INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "300kb" }));
app.use(express.urlencoded({ extended: false, limit: "300kb" }));
app.use(session({
  name: "slayr.sid",
  secret: process.env.SESSION_SECRET || "local-development-secret-change-before-deploy-000",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 24 }
}));
app.use("/api", rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false }));
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 512 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => cb(null, /\.(lua|luau)$/i.test(file.originalname))
});
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in to continue." });
  next();
}
function getUser(id) {
  return db.prepare("SELECT id, username, created_at FROM users WHERE id = ?").get(id);
}
function getDashboard(id) {
  const user = getUser(id);
  if (!user) return null;
  const stats = db.prepare(`
    SELECT COUNT(*) AS total, COALESCE(SUM(source_bytes),0) AS sourceBytes,
    COALESCE(SUM(output_bytes),0) AS outputBytes
    FROM jobs WHERE user_id = ?`).get(id);
  const recent = db.prepare("SELECT id, name, description, source_bytes, output_bytes, created_at FROM jobs WHERE user_id = ? ORDER BY id DESC LIMIT 8").all(id);
  return { user, stats, recent };
}
app.post("/api/auth/register", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(username))
    return res.status(400).json({ error: "Username must be 3–24 characters: letters, numbers, or underscores." });
  if (password.length < 8 || password.length > 128)
    return res.status(400).json({ error: "Password must be 8–128 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)").run(username, hash);
    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "Could not start your session." });
      req.session.userId = Number(result.lastInsertRowid);
      res.json({ dashboard: getDashboard(req.session.userId) });
    });
  } catch {
    res.status(409).json({ error: "That username is already taken." });
  }
});
app.post("/api/auth/login", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT id, password_hash FROM users WHERE username = ?").get(username);
  if (!user || !(await bcrypt.compare(password, user.password_hash)))
    return res.status(401).json({ error: "Incorrect username or password." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start your session." });
    req.session.userId = user.id;
    res.json({ dashboard: getDashboard(user.id) });
  });
});
app.post("/api/auth/logout", auth, (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: "Could not log out." });
    res.clearCookie("slayr.sid");
    res.json({ ok: true });
  });
});
app.get("/api/me", auth, (req, res) => {
  const data = getDashboard(req.session.userId);
  if (!data) return res.status(401).json({ error: "Account not found." });
  res.json(data);
});
app.post("/api/change-password", auth, async (req, res) => {
  const currentPassword = String(req.body.currentPassword || "");
  const newPassword = String(req.body.newPassword || "");
  const row = db.prepare("SELECT password_hash FROM users WHERE id = ?").get(req.session.userId);
  if (!row || !(await bcrypt.compare(currentPassword, row.password_hash)))
    return res.status(400).json({ error: "Your current password is incorrect." });
  if (newPassword.length < 8 || newPassword.length > 128)
    return res.status(400).json({ error: "New password must be 8–128 characters." });
  const hash = await bcrypt.hash(newPassword, 12);
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, req.session.userId);
  res.json({ ok: true });
});

/*
 * Built-in source transformer: strips ordinary comments and compresses safe
 * whitespace while preserving quoted strings, backtick strings, long-bracket
 * strings/comments, and token boundaries. This is lightweight minification,
 * NOT strong obfuscation or a substitute for a Luau-aware obfuscator.
 */
function transformLuau(source) {
  let out = "", i = 0, pendingSpace = false;
  const isWord = c => !!c && /[A-Za-z0-9_]/.test(c);
  const pushSpace = () => { pendingSpace = true; };
  const emit = token => {
    if (pendingSpace && out && isWord(out[out.length - 1]) && isWord(token[0])) out += " ";
    pendingSpace = false; out += token;
  };
  while (i < source.length) {
    const c = source[i], n = source[i + 1];
    if (/\s/.test(c)) { pushSpace(); i++; continue; }
    if (c === "-" && n === "-") {
      let j = i + 2, eq = 0;
      if (source[j] === "[") {
        j++;
        while (source[j] === "=") { eq++; j++; }
        if (source[j] === "[") {
          j++;
          const close = "]" + "=".repeat(eq) + "]";
          const end = source.indexOf(close, j);
          i = end < 0 ? source.length : end + close.length;
          pushSpace(); continue;
        }
      }
      i += 2;
      while (i < source.length && source[i] !== "\n" && source[i] !== "\r") i++;
      pushSpace(); continue;
    }
    if (c === "'" || c === '"' || c === "`") {
      const quote = c; let token = c; i++;
      while (i < source.length) {
        const ch = source[i++]; token += ch;
        if (ch === "\\" && i < source.length) token += source[i++];
        else if (ch === quote) break;
      }
      emit(token); continue;
    }
    if (c === "[") {
      let j = i + 1, eq = 0;
      while (source[j] === "=") { eq++; j++; }
      if (source[j] === "[") {
        j++;
        const close = "]" + "=".repeat(eq) + "]";
        const end = source.indexOf(close, j);
        const finish = end < 0 ? source.length : end + close.length;
        emit(source.slice(i, finish)); i = finish; continue;
      }
    }
    if (isWord(c)) {
      let j = i + 1;
      while (j < source.length && isWord(source[j])) j++;
      emit(source.slice(i, j)); i = j; continue;
    }
    const op = ["...", "..", "==", "~=", "<=", ">=", "::", "//", "+=", "-=", "*=", "/=", "%=", "^=", "->", "&&", "||"];
    const found = op.find(x => source.startsWith(x, i));
    if (found) { emit(found); i += found.length; }
    else { emit(c); i++; }
  }
  return out.trim();
}
function handleTransform(req, res, source) {
  const name = String(req.body.name || "").trim().slice(0, 80);
  const description = String(req.body.description || "").trim().slice(0, 300);
  if (!name) return res.status(400).json({ error: "Enter a script name." });
  if (!source.trim()) return res.status(400).json({ error: "Paste or upload some Luau code first." });
  if (Buffer.byteLength(source, "utf8") > 200 * 1024) return res.status(413).json({ error: "Code is limited to 200 KB per job." });
  const output = transformLuau(source);
  db.prepare("INSERT INTO jobs (user_id, name, description, source_bytes, output_bytes) VALUES (?, ?, ?, ?, ?)")
    .run(req.session.userId, name, description, Buffer.byteLength(source), Buffer.byteLength(output));
  res.json({ output, stats: getDashboard(req.session.userId).stats, notice: "Basic minification complete. This is not strong obfuscation." });
}
app.post("/api/obfuscate", auth, (req, res) => handleTransform(req, res, String(req.body.code || "")));
app.post("/api/obfuscate-file", auth, upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Choose a .lua or .luau file (max 512 KB)." });
  handleTransform(req, res, req.file.buffer.toString("utf8"));
});
app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: "File upload failed or exceeds 512 KB." });
  res.status(400).json({ error: "Request could not be processed." });
});
app.listen(port, () => console.log(`Slayr Protect listening on ${port}`));
