# Slayr Protect

A custom dark dashboard starter with:
- Username/password registration and login (bcrypt password hashing)
- SQLite-backed accounts and job history
- Dashboard counts and recent activity
- Paste Luau source or upload `.lua` / `.luau`
- Basic source minification, output copy/download
- Password change and logout
- Railway-ready `npm start`

## Important about the transformer

The built-in transformer strips ordinary comments and compresses whitespace while preserving strings and token boundaries. It is **basic minification, not strong obfuscation**. Luau parsing has edge cases, and this simple transformer is not a replacement for a real Luau-aware obfuscator. Test the output in a safe Roblox Studio test place before using it in a production game.

## Run locally

Requires Node.js 20 or newer.

```bash
cp .env.example .env
npm install
npm start
```

Set `SESSION_SECRET` in `.env` to a random string at least 32 characters long, then open http://localhost:3000. Choose **Create account** for your first user.

## Deploy on GitHub + Railway

1. Create a GitHub repository and upload the project files (keep `package.json` and `server.js` in the repository root).
2. In Railway, create a project from that GitHub repository.
3. Set `SESSION_SECRET` to a long random secret and `NODE_ENV=production`.
4. Add a Railway Volume mounted at `/app/data`. The app stores its SQLite database in `RAILWAY_VOLUME_MOUNT_PATH` when Railway sets it, or in `./data` otherwise.
5. Deploy and open the Railway domain.

## Production hardening

This is a starter, not a fully audited production service. Express's default in-memory session store is not suitable for multi-instance production. Before serving public users, use a persistent session store, add CSRF protection, consider PostgreSQL for multi-instance hosting, and thoroughly test the source transformer. Do not market minification as strong anti-reverse-engineering protection.
