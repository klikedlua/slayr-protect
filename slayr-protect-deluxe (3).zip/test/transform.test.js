const test = require("node:test");
const assert = require("node:assert/strict");
const { minifyLuau } = require("../lib/transform");

test("removes line comments and collapses whitespace", () => {
  assert.equal(minifyLuau("local value = 3 -- comment\nprint(value)"), "local value=3 print(value)");
});
test("keeps quoted strings unchanged", () => {
  assert.equal(minifyLuau('local s = "a  -- b"\nprint(s)'), 'local s="a  -- b" print(s)');
});
test("keeps long bracket strings", () => {
  assert.equal(minifyLuau("local s = [=[hello\nworld]=]"), "local s=[=[hello\nworld]=]");
});
test("does not join two minus operators into a comment", () => {
  assert.equal(minifyLuau("local n = a - -b"), "local n=a- -b");
});
test("preserves identifier boundaries", () => {
  assert.equal(minifyLuau("local hello = world"), "local hello=world");
});
test("strips long bracket comments", () => {
  assert.equal(minifyLuau("local x=1 --[=[ multi\ncomment ]=]\nreturn x"), "local x=1 return x");
});
test("does not consume concatenation dots as part of a number", () => {
  assert.equal(minifyLuau("return 1 .. 2"), "return 1..2");
});
test("preserves numeric exponent signs", () => {
  assert.equal(minifyLuau("local n = 1e-3"), "local n=1e-3");
});
test("does not merge punctuation tokens across original whitespace", () => {
  assert.equal(minifyLuau("local x = a + = b"), "local x=a+ =b");
});
test("preserves underscores in numeric literals", () => {
  assert.equal(minifyLuau("return 1_000"), "return 1_000");
});
