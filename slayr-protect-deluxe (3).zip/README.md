# Slayr Protect — custom starter

A complete small Node.js project for a dark Luau script workspace.

## Included
- Account registration/login with bcrypt password hashing
- SQLite accounts and per-user script job history
- Dashboard statistics and recent activity
- Paste editor or `.lua` / `.luau` file upload
- Source minifier with copy/download output
- Password change and logout
- API rate limiting, Helmet headers, upload size limits, health check
- Railway config, Dockerfile, environment example, tests

## Honest note about the engine
The bundled `lib/transform.js` is a conservative lexical minifier. It strips comments and redundant whitespace while attempting to preserve strings and token boundaries. **It is not strong obfuscation**, and it is not a full Luau parser. Test outputs in a disposable Roblox Studio place before relying on them. If you want real control-flow or constant obfuscation, integrate a trusted Luau-aware engine.

## Run locally
Use Node.js 20 or newer.

```bash
cp .env.example .env
# Put a long random value in SESSION_SECRET
npm install
npm test
npm start
```

Visit `http://localhost:3000`, choose **Create account**, then sign in.

## Deploy from GitHub to Railway
1. Create a GitHub repository and upload the project files. `package.json` and `server.js` must be at the repository root.
2. In Railway, deploy from that repository.
3. Set `SESSION_SECRET` to a random secret of at least 32 characters and set `NODE_ENV=production`.
4. Add a Railway Volume mounted at `/app/data`. The app writes its SQLite database under `RAILWAY_VOLUME_MOUNT_PATH` if Railway sets it.
5. Deploy. Railway uses `railway.json` for the Dockerfile build and `/health` health check.

## Production caveats
This is a starter, not a security-audited SaaS. Express's default in-memory session store is unsuitable for multi-instance production; use a persistent session store. For multi-instance deployments, prefer PostgreSQL. Add CSRF protection and verify the exact behavior of the transformer before opening the service to public users.
